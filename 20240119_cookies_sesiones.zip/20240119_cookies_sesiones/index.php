<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Principal</title>

    <link rel="stylesheet" href="styles.css">
</head>
<body>
<h1>Página Principal</h1>
<?php
// Verifica si la sesión está iniciada
if (isset($_SESSION['user_id'])) {
    echo '<p>Bienvenido, '.$_SESSION['user_name'].'!</p>';
    echo '<p><a href="recursos.php">Ir a recursos</a></p>';
    echo '<p><a href="logout.php">Cerrar sesión</a></p>';
} else {
    echo '<p><a href="login.php">Iniciar sesión</a> para acceder a los recursos.</p>';
}
?>
</body>
</html>
