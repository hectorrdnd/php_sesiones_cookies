<?php
session_start();

// Verificar si se enviaron los datos del formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recuperar los datos del formulario
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    // Aquí debes realizar la validación de usuario y contraseña
    // Verifica el correo y contraseña con los datos almacenados de forma segura

    // Supongamos que $validacion es un resultado de la validación
    $validacion = true; // Puedes cambiar esto según tu lógica de validación

    if ($validacion) {
        // Asigna valores de ejemplo para $usuario_id y $usuario_nombre
        $usuario_id = 1;
        $usuario_nombre = 'NombreUsuario';

        // Si la validación es exitosa, establece la sesión
        $_SESSION['user_id'] = $usuario_id; // Asigna el ID del usuario
        $_SESSION['user_name'] = $usuario_nombre; // Asigna el nombre del usuario

        header('Location: recursos.php');
        exit();
    } else {
        // Si la validación falla, redirige nuevamente a la página de inicio de sesión
        header('Location: login.php');
        exit();
    }
} else {
    // Si no se envió el formulario, redirige a la página de inicio de sesión
    header('Location: login.php');
    exit();
}
?>
