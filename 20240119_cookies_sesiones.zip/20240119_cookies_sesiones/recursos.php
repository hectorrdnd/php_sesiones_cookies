<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recursos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body class="bg-gray-100 font-sans">

<!-- Barra de navegación -->
<nav class="bg-blue-500 p-4 text-white">
    <div class="container mx-auto">
        <a href="index.php" class="text-lg font-bold">Mi Escuela</a>
    </div>
</nav>

<!-- Contenido de la página -->
<div class="container mx-auto p-4 mt-8">

    <h1 class="text-3xl font-bold text-blue-500 mb-8">Recursos</h1>

    <!-- Contenido principal -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <!-- Archivo 1 -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold mb-4">Archivo 1</h2>
            <a href="doc/archivo1.pdf" class="text-blue-500 hover:underline">Ver PDF</a>
        </div>

        <!-- Archivo 2 -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold mb-4">Archivo 2</h2>
            <a href="doc/archivo2.pdf" class="text-blue-500 hover:underline">Ver PDF</a>
        </div>

        <!-- Archivo 3 -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold mb-4">Archivo 3</h2>
            <a href="doc/archivo3.pdf" class="text-blue-500 hover:underline">Ver PDF</a>
        </div>
    </div>

</div>

<!-- Pie de página -->
<footer class="bg-gray-800 text-white p-4">
    <div class="container mx-auto text-center">
        <p>&copy; 2024 Mi Escuela</p>
    </div>
</footer>

</body>
</html>
