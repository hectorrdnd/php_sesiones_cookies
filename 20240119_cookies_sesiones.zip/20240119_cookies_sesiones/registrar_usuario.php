<?php
// Aquí debes realizar la lógica para registrar al usuario en la base de datos
// Asegúrate de cifrar la contraseña con un algoritmo seguro (por ejemplo, password_hash)

header('Location: login.php');
exit();
?>
