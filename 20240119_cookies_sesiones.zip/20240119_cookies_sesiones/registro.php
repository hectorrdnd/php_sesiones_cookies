<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escuela - Registro</title>
    <!-- Agrega la referencia a Tailwind CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<h2>Registro</h2>
<form action="registrar_usuario.php" method="post">
    <div class="mb-4">
        <label for="correo" class="block text-gray-700 text-sm font-bold mb-2">Correo electrónico:</label>
        <input type="email" id="correo" name="correo" class="border rounded w-full py-2 px-3" required>
    </div>
    <div class="mb-4">
        <label for="contrasena" class="block text-gray-700 text-sm font-bold mb-2">Contraseña:</label>
        <input type="password" id="contrasena" name="contrasena" class="border rounded w-full py-2 px-3" required>
    </div>
    <div class="mb-4">
        <label for="confirmar_contrasena" class="block text-gray-700 text-sm font-bold mb-2">Confirmar contraseña:</label>
        <input type="password" id="confirmar_contrasena" name="confirmar_contrasena" class="border rounded w-full py-2 px-3" required>
    </div>
    <div class="mb-4">
        <input type="checkbox" id="acepto_politica" name="acepto_politica" required>
        <label for="acepto_politica" class="ml-2 text-gray-700 text-sm font-bold">Acepto la política de privacidad</label>
    </div>
    <div>
        <input type="submit" value="Registrarse" class="bg-blue-500 text-white py-2 px-4 rounded">
    </div>
</form>
</body>
</html>
